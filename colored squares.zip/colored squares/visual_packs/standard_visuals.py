graphics_strings = {
    "wall": "\033[100m", 
    "air": "\033[107m", 
    "player": "\033[97;41m", 
    "goal": "\033[97;102m", 
    "coin": "\033[103m", 
    "box": "\033[104m", 
    "hole": "\033[40m"
}