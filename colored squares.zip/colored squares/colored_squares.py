from sys import exit
from copy import deepcopy

#main inicialization
#map tiles (allows for easier map creation)
wall, air, coin, box, player, goal, hole = "wall", "air", "coin", "box", "player", "goal", "hole"

#main menu
print("\n\033[1;91mColored squares \033[0m by \033[34m Artur Balák\033[0m \nType 'how to play', 'how to make', 'exit' or a name of a level pack to play it.\nBuilt in level pack: 'tutorial'\n")
while True:
    inp = input()

    if inp == "exit":
        exit()
    elif inp == "how to play":
        print("You move with the wasd keys (this is python so don't forget to press enter after each input).\n\nRed box - player - you control it\nWhite box - air - you can walk into it\nGray box - wall - you can't walk into it\nGreen box - goal - you have to get to it\nYellow box - coin - you have to have them all\nBlue box - box - pushable, don't trap yourself!\nBlack box - hole - stuff can fall in, then hole is gone\n\nThe number inside red and blue boxes represents their group, players have to get to any goal in the same category.\nFor some easy levels to test all of this, play the 'tutorial' levelpack. Please note that this information applies only to the standard set of rules and visuals.")
    elif inp == "how to make":
        print("ask me on discord because it's complicated")
    else:
        level_pack_name = inp
        break
    
#level loading preparation

with open("./level_packs/" + level_pack_name + ".txt") as level_pack:
    levels = level_pack.readlines(0)

exec("rule_pack_name, visual_pack_name = " + str(levels[0]))
exec("from rule_packs." + rule_pack_name + " import *")
exec("from visual_packs." + visual_pack_name + " import *")

#the game
for level_index in range(1,len(levels)):
    load_next_level = False

    #level input
    
    exec("map, level_name = " + str(levels[level_index]))

    #get the map size
    map_size = [len(map[0]), len(map)]

    for i in map:
        if len(i) != map_size[0]:
            print("Invalid level")
            exit()
    
    #format the map
    for i in range(map_size[0]):
        for j in range(map_size[1]):
            if type(map[j][i]) == type(""):
                map[j][i] = [map[j][i], "  "]
            elif len(str(map[j][i][1])) == 1:
                map[j][i][1] = " " + str(map[j][i][1])
            elif len(str(map[j][i][1])) == 0:
                map[j][i][1] = "  "
            elif len(str(map[j][i][1])) > 2:
                print("Invalid level")
                exit()

    #copy it for restart level purposes
    map_copy = deepcopy(map)
    
    #level text
    print("\nLevel " +  str(level_index) +  "/" + str(len(levels)-1) + ": '" + level_name + "'\n")
    #the level
    while True:    
        if load_next_level:
            break
        
        #inicialization
        coords, goal_coords = [], []
        player_count = 0
        load_next_level = False

        #reset map on restart
        map = deepcopy(map_copy)

        #find all players and goals to keep track of their positions and to count them
        for i in range(map_size[0]):
            for j in range(map_size[1]):
                if map[j][i][0] in controlled:
                    coords.append([i, j, map[j][i][1], map[j][i][0]])
                elif map[j][i][0] in goals:
                    goal_coords.append([i, j, map[j][i][1], map[j][i][0]])

        while True:
            #graphics
            for i in map:
                for j in i:
                    print(graphics_strings[j[0]] + str(j[1]), end="")
                print("\033[0m  ")

            #winning check
            winning_condition = False
            coordinate_overlaps = len(coords) + len(goal_coords)

            for i in coords:
                for j in goal_coords:
                    if i[:3] == j[:3]:
                        coordinate_overlaps -= 2

            if coordinate_overlaps == 0:
                winning_condition = True

            for i in map:
                for j in i:
                    if j[0] in collectable:
                        winning_condition = False
                        break

            if winning_condition:
                input("You won the level '" + level_name + "'! Press enter to continue.")
                load_next_level = True
                break

            #movement
            to_remove = []
            to_move = coords
            inp = input("Input [w][a][s][d] - movement; [r]estart; [exit]: ")
            if inp == "exit":
                exit()
            elif inp == "r":
                break

            elif inp == "w":
                while len(to_move) != 0:
                    for i in to_move:
                        
                        if i[1] == 0:                                                                                   #if player is on map enge, ignore command
                            continue
                        elif map[i[1]-1][i[0]][0] in steppable:                                                         #basic walking
                            map[i[1]][i[0]] = empty
                            coords[][1] -= 1
                        elif map[i[1]-1][i[0]][0] in fillable:                                                          #basic walking into a hole
                            map[i[1]-1][i[0]] = empty
                            to_remove.append(i[2])
                                
                        elif map[i[1]-1][i[0]][0] in controlled:
                            to_move.append(i)
                        
                        elif i[1] - 1 != 0:                                                                             #map edge check for pushing operations
                            if map[i[1]-1][i[0]][0] in pushable and map[i[1]-2][i[0]][0] in pushable_into:              #block pushing
                                map[i[1]][i[0]] = empty
                                map[i[1]-2][i[0]] = map[i[1]-1][i[0]]
                                map[i[1]-1][i[0]] = empty
                                i[1] -= 1
                            if map[i[1]-1][i[0]][0] in pushable and map[i[1]-2][i[0]][0] in fillable:                   #block pushing into a hole
                                map[i[1]][i[0]] = empty
                                map[i[1]-2][i[0]] = empty
                                map[i[1]-1][i[0]] = empty
                                i[1] -= 1
                        to_move.remove(i)

            elif inp == "a":
                for i in to_move:
                    if i[0] == 0:
                        continue
                    elif map[i[1]][i[0]-1][0] in steppable:
                        map[i[1]][i[0]] = empty
                        if map[i[1]][i[0]-1][0] in fillable:
                            map[i[1]][i[0]-1] = empty
                            to_remove.append(i[2])
                        else:
                            i[0] -= 1
                    elif i[0] - 1 != 0:  
                        if map[i[1]][i[0]-1][0] in controlled and map[i[1]][i[0]-2][0] in steppable:
                            map[i[1]][i[0]] = empty
                            i[0] -= 1
                        elif map[i[1]][i[0]-1][0] in pushable and map[i[1]][i[0]-2][0] in pushable_into:
                            map[i[1]][i[0]] = empty
                            if map[i[1]][i[0]-2][0] in fillable:
                                map[i[1]][i[0]-2] = empty
                            else:
                                map[i[1]][i[0]-2] = map[i[1]][i[0]-1]
                            map[i[1]][i[0]-1] = empty
                            i[0] -= 1

            elif inp == "s":
                for i in to_move:
                    if i[1] == map_size[1] - 1:
                        continue
                    elif map[i[1]+1][i[0]][0] in steppable:
                        map[i[1]][i[0]] = empty
                        if map[i[1]+1][i[0]][0] in fillable:
                            map[i[1]+1][i[0]] = empty
                            to_remove.append(i[2])
                        else:
                            i[1] += 1
                    elif i[1] + 1 != map_size[1] - 1:
                        if map[i[1]+1][i[0]][0] in controlled and map[i[1]+2][i[0]][0] in steppable:
                            map[i[1]][i[0]] = empty
                            i[1] += 1
                        elif map[i[1]+1][i[0]][0] in pushable and map[i[1]+2][i[0]][0] in pushable_into:
                            map[i[1]][i[0]] = empty
                            if map[i[1]+2][i[0]][0] in fillable:
                                map[i[1]+2][i[0]] = empty
                            else:
                                map[i[1]+2][i[0]] = map[i[1]+1][i[0]]
                            map[i[1]+1][i[0]] = empty
                            i[1] += 1

            elif inp == "d":
                for i in to_move:
                    if i[0] == map_size[0] - 1:
                        continue
                    elif map[i[1]][i[0]+1][0] in steppable:
                        map[i[1]][i[0]] = empty
                        if map[i[1]][i[0]+1][0] in fillable:
                            map[i[1]][i[0]+1] = empty
                            to_remove.append(i[2])
                        else:
                            i[0] += 1
                    elif i[0] + 1 != map_size[0] - 1:
                        if map[i[1]][i[0]+1][0] in controlled and map[i[1]][i[0]+2][0] in steppable:
                            map[i[1]][i[0]] = empty
                            i[0] += 1
                        elif map[i[1]][i[0]+1][0] in pushable and map[i[1]][i[0]+2][0] in pushable_into:
                            map[i[1]][i[0]] = empty
                            if map[i[1]][i[0]+2][0] in fillable:
                                map[i[1]][i[0]+2] = empty
                            else:
                                map[i[1]][i[0]+2] = map[i[1]][i[0]+1]
                            map[i[1]][i[0]+1] = empty
                            i[0] += 1
                    
            #rewriting the map (player has priority so gets placed last)
            for i in coords:
                if i[2] in to_remove:
                    coords.remove(i)
            
            for i in goal_coords:
                map[i[1]][i[0]] = [i[3], i[2]]

            for i in coords:
                map[i[1]][i[0]] = [i[3], i[2]]

input("\nYou have finished the level pack: '" + str(level_pack_name) + "'\nTo play another level pack, launch the game again.\n\n Press enter to continue")